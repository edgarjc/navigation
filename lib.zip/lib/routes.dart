import 'package:go_router/go_router.dart';
import 'package:navigation/screens/home.dart';
import 'package:navigation/screens/nested.dart';
import 'package:navigation/screens/settings.dart';

import 'main.dart';

final GoRouter router = GoRouter(
  debugLogDiagnostics: true,
  initialLocation: '/home',
  routes: [
    ShellRoute(
      builder: (context, state, child) {
        final location = GoRouterState.of(context).matchedLocation;

        return ScaffoldWithNavBar(
          child: child,
          location: location,
        );
      },
      routes: [
        GoRoute(
            path: '/home',
            builder: (context, state) => HomeScreen(),
            routes: [
              GoRoute(
                path: 'nestedScreen',
                builder: (context, state) => NestedScreen(),
              ),
            ]
        ),
        GoRoute(
            path: '/nested',
            builder: (context, state) => SettingsScreen(),
            /*routes: [
              GoRoute(
                path: 'nestedScreen2',
                builder: (context, state) => HomeScreen(),
              ),
            ]*/),
      ],
    ),
  ],
);