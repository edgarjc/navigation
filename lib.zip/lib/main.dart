import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:navigation/routes.dart';
import 'package:navigation/screens/home.dart';
import 'package:navigation/screens/settings.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {

    return MaterialApp.router(
      routerConfig: router,
    );
  }
}

class ScaffoldWithNavBar extends StatefulWidget {
  final Widget child;
  final String location;
  ScaffoldWithNavBar({required this.child, required this.location});

  @override
  State<ScaffoldWithNavBar> createState() => _ScaffoldWithNavBarState();
}

class _ScaffoldWithNavBarState extends State<ScaffoldWithNavBar> {
  int _currentIndex = 0;

  final List<Widget> _children = [
    HomeScreen(),
    SettingsScreen(),
    // Add more screens here...
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: _children,
      ),
      bottomNavigationBar: NavigationBar(
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          NavigationDestination(
            icon: Icon(Icons.settings),
            label: 'Settings',
          ),
        ],
        onDestinationSelected: (index) {
          setState(() {
            _currentIndex = index;
          });
          context.go(index == 0 ? '/home' : '/nested');

          /* if (index == 0) {
            context.go('/home');
          } else if (index == 1) {
            context.go('/nested');
          }*/
        },
        selectedIndex: widget.location.startsWith('/home') ? 0 : 1,
      ),
    );
  }
}


