import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';


class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Column(
        children: [
          SizedBox(height: 150,),
          Center(
            child: Text('Home screen'),
          ),
          ElevatedButton(onPressed: (){
            //print("pushing settings");
            GoRouter.of(context).push('/nested');
          }, child: Text("Nested Settings"))
        ],
      ),
    );
  }
}